package ambulance.system;

import javax.swing.*;
import java.awt.*;

public class ShortStay {

    public static void main(String[] args) {
        // Create the main frame
        JFrame frame = new JFrame("Hospital Admission");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1200, 800);
        frame.setLayout(new BorderLayout());

        // Load and resize image
        ImageIcon imageIcon = new ImageIcon("C:\\Users\\Payal\\OneDrive\\Desktop\\short-stay-service-banner.jpg");
        Image image = imageIcon.getImage();
        Image newimg = image.getScaledInstance(frame.getWidth(), 400, java.awt.Image.SCALE_SMOOTH);
        imageIcon = new ImageIcon(newimg);
        JLabel imageLabel = new JLabel(imageIcon);
        imageLabel.setHorizontalAlignment(SwingConstants.CENTER);

        // Create the text panel
        JPanel textPanel = new JPanel();
        textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));
        textPanel.setBackground(new Color(240, 240, 240)); // Light gray background

        // Add title
        JLabel titleLabel = new JLabel("Wheelchair In The Morning, On Your Couch By Evening", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Serif", Font.BOLD, 28));
        titleLabel.setForeground(new Color(0, 102, 204)); // Dark blue color

        // Add subtitle
        JLabel subtitleLabel = new JLabel("All in a day's work with Short Stay", SwingConstants.CENTER);
        subtitleLabel.setFont(new Font("Serif", Font.ITALIC, 20));
        subtitleLabel.setForeground(new Color(102, 102, 102)); // Gray color

        // Add contact info
        JLabel contactLabel = new JLabel("Call For Booking: 022 2444 7500 Ext. 8276 / 3404", SwingConstants.CENTER);
        contactLabel.setFont(new Font("Serif", Font.PLAIN, 18));
        contactLabel.setForeground(new Color(255, 102, 0)); // Orange color

        // Add components to the text panel
        textPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        textPanel.add(titleLabel);
        textPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        textPanel.add(subtitleLabel);
        textPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        textPanel.add(contactLabel);
        textPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        // Add sections using the helper method
        JPanel aboutPanel = createSectionPanel("About Short Stay Service",
                "The Short Stay Service is a unique concept initiated by P. D. Hinduja Hospital that caters to patients undergoing surgeries and procedures that require a day's stay in the hospital. The most common procedures done under day care surgeries are: cataract, general surgery, ENT, removal of cysts and more. All category of surgeries which require only a day stay are done in Short Stay Service which can belong to Minor, Intermediate, Major, Major Plus category. The 19-bedded Short Stay Service Unit (SSSU) is dedicated facility that acts like a hospital within a hospital wherein a patient can get admitted in the morning and is discharged the same day evening. The department is open round the clock except holidays and Sundays.");

        JPanel bookingsPanel = createSectionPanel("Bookings & Admissions",
                "While booking an admission, all formalities need to be completed along with a payment of ₹5000, after which a reservation number will be given. This amount will be adjustable in your final bill. In case of cancellation, the amount will be refunded only based on a doctor's letter.\n\n"
                        + "In case of Telephonic Bookings, you may email a scanned copy of the admission note by the doctor and other documents to sss@hindujahospital.com or fax them to 02224445907, mentioning your contact number and your HH No. (if you have).\n\n"
                        + "Patients are also requested to mention their mobile number to receive the booking status and email ids to receive laboratory reports while booking. The laboratory reports can be viewed online on the hospital website.\n\n"
                        + "Instructions:\n"
                        + "As much as we would like to provide you with your preference of accommodation, due to overload in admissions, reservation does not confirm the bed of your choice. You will receive a confirmation call between 11 AM to 7 PM from the customer care a day prior to the date of expected admission. In case you do not receive any confirmation call, please call on 9757 33 0707 between 8 AM to 8 PM. Admission timings will be informed as per bed availability. Although complete care is taken to allot you a bed at the assured time, kindly bear with us in unforeseen circumstances.");

        JPanel postAdmissionPanel = createSectionPanel("Post Admission Instructions",
                "Bed allotment is done as per availability.\n"
                        + "Please wear hospital clothes as well as the Patient ID band throughout your stay in the hospital.\n"
                        + "Home food for patient may be permitted only on \"medical grounds\". Attendant's meal can be procured on chargeable basis after admission.\n"
                        + "Consumption of alcohol, smoking and chewing of tobacco is prohibited.\n"
                        + "Please safeguard your valuables & mobile. The hospital will not be liable for any loss of money or valuables.\n"
                        + "Please respect hospital and personal property.\n"
                        + "After admission, nurses will take patient vitals and inform doctor about patient's status to carry out further instructions.");

        JPanel surgicalPatientsPanel = createSectionPanel("Surgical Patients Instructions",
                "Post receiving fitness for surgery, patient will be transferred to OT/Procedure room.\n"
                        + "After surgery and patient is shifted to recovery, SSSU nurse will inform patient's relative.\n"
                        + "Based on patient's status, it may take 2-3 hrs to receive patient back in the unit.\n"
                        + "Patient is then monitored and any post-operative orders related to investigations, diet etc. are carried out.\n"
                        + "Finalization of discharge summary is done after patient is fit for discharge.");

        // Create the tabbed pane
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("For Admission", createSectionPanel("Admission Instructions",
                "• You need to report in Short stay department located at 4th floor, West block building.\n"
                        + "• Please show your booking letter to security to allow access to SSSU.\n"
                        + "• You may call our Customer Care Staff at 9757330707 for escorting you to SSSU.\n"
                        + "• Please come with all reports as advised by the doctor.\n"
                        + "• Admission process is done at the SSSU counter itself.\n"
                        + "• All patients are requested to sign a declaration for payment as per the hospital charges.\n"
                        + "• Patients seeking cashless service in SSSU need to make a payment of ₹7500/- as security deposit. This amount is subject to refund as per clauses of bill settlement by insurance company/TPA. For patients undergoing chemotherapy in SSSU have to pay ₹2500 for every admission."));
        tabbedPane.addTab("Post Admission", postAdmissionPanel);
        tabbedPane.addTab("Surgical Patients", surgicalPatientsPanel);
        tabbedPane.addTab("Medical Patients", createSectionPanel("Medical Patients Instructions",
                "Post assessment of patient's fitness for therapy, doctors give drug orders.\n"
                        + "Nurses then arrange, prepare and administer drugs for the patient.\n"
                        + "Patient is then monitored till completion of the therapy.\n"
                        + "Finalization of discharge summary is done after patient is declared fit for discharge by the doctor."));
        tabbedPane.addTab("Chemotherapy", createSectionPanel("Chemotherapy Instructions",
                "For patients undergoing chemotherapy, chemo initiation may take 1-2hrs from the time of admission depending on report review findings."));

        // Create the main content panel
        JPanel mainContentPanel = new JPanel();
        mainContentPanel.setLayout(new BorderLayout());
        mainContentPanel.setBackground(new Color(240, 240, 240)); // Light gray background
        mainContentPanel.add(imageLabel, BorderLayout.NORTH);
        mainContentPanel.add(textPanel, BorderLayout.CENTER);
        mainContentPanel.add(tabbedPane, BorderLayout.SOUTH);

        // Wrap the main content panel in a JScrollPane
        JScrollPane scrollPane = new JScrollPane(mainContentPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        // Add scroll pane to frame
        frame.add(scrollPane, BorderLayout.CENTER);

        // Set frame visibility
        frame.setVisible(true);
    }

    private static JPanel createSectionPanel(String title, String content) {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1, true));
        panel.setBackground(new Color(255, 255, 255)); // White background

        // Title label
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Sans Serif", Font.BOLD, 20));
        titleLabel.setForeground(new Color(0, 102, 204)); // Dark blue color
        titleLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Content area
        JTextArea textArea = new JTextArea(content);
        textArea.setFont(new Font("Sans Serif", Font.PLAIN, 18));
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setEditable(false);
        textArea.setBackground(panel.getBackground());
        textArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Add components to panel
        panel.add(titleLabel, BorderLayout.NORTH);
        panel.add(new JScrollPane(textArea), BorderLayout.CENTER);

        return panel;
    }
}
