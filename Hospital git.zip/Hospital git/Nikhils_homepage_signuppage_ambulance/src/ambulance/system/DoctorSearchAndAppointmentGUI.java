
package ambulance.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class DoctorSearchAndAppointmentGUI {

    private static JPanel doctorListPanel;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Doctor Search and Appointment Booking");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(800, 600);
            frame.setLayout(new BorderLayout());

            // Top Panel with Search Bar
            JPanel topPanel = new JPanel(new BorderLayout());
            topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

            JTextField searchField = new JTextField("Search by Doctor's Name");
            JButton searchButton = new JButton("Search");
            searchButton.setBackground(Color.decode("#159cc5"));
            
            
            JPanel searchPanel = new JPanel(new BorderLayout());
            searchPanel.add(searchField, BorderLayout.CENTER);
            searchPanel.add(searchButton, BorderLayout.EAST);

            topPanel.add(searchPanel, BorderLayout.CENTER);

            frame.add(topPanel, BorderLayout.NORTH);

            // Center Panel with Alphabetical Filter and Lists
            JPanel centerPanel = new JPanel(new BorderLayout());

            JPanel alphabetPanel = new JPanel(new GridLayout(1, 27));
            alphabetPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
            for (char alphabet = 'A'; alphabet <= 'Z'; alphabet++) {
                JButton button = new JButton(String.valueOf(alphabet));
                button.setBackground(Color.decode("#159cc5"));
                button.addActionListener(new AlphabetButtonListener());
                alphabetPanel.add(button);
            }
            JButton allButton = new JButton("ALL");
            allButton.addActionListener(new AlphabetButtonListener());
            alphabetPanel.add(allButton);
            allButton.setBackground(Color.decode("#159cc5"));
            
            
            centerPanel.add(alphabetPanel, BorderLayout.NORTH);

            doctorListPanel = new JPanel(new GridLayout(0, 3, 10, 10));
            doctorListPanel.setBorder(BorderFactory.createTitledBorder("Doctors"));

            // Load and display all doctors initially
            updateDoctorList("ALL");

            JScrollPane scrollPane = new JScrollPane(doctorListPanel);
            scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
            scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);

            centerPanel.add(scrollPane, BorderLayout.CENTER);

            frame.add(centerPanel, BorderLayout.CENTER);

            // Add search button action listener
            searchButton.addActionListener(e -> {
                String searchText = searchField.getText().trim().toUpperCase();
                if (!searchText.isEmpty()) {
                    updateDoctorList(String.valueOf(searchText.charAt(0)));
                }
            });

            frame.setLocationRelativeTo(null); // Center the frame on the screen
            frame.setVisible(true);
        });
    }

    private static void updateDoctorList(String letter) {
        doctorListPanel.removeAll();
        List<Doctor> doctors = getDoctorNamesStartingWith(letter);
        for (Doctor doctor : doctors) {
            doctorListPanel.add(createDoctorPanel(
                    doctor.getName(),
                    doctor.getTitle(),
                    doctor.getQualifications(),
                    doctor.getImagePath()
            ));
        }
        doctorListPanel.revalidate();
        doctorListPanel.repaint();
    }

    private static List<Doctor> getDoctorNamesStartingWith(String letter) {
        // Dummy data - replace with actual data retrieval
        List<Doctor> allDoctors = new ArrayList<>();
        allDoctors.add(new Doctor("Dr. Asha Kapadia", "Head of the Department of Medicine and Section Head of Oncology", "MD (USA), DABP", "C:\\Users\\Payal\\OneDrive\\Desktop\\hospital java\\women1.jpg"));
        allDoctors.add(new Doctor("Dr. Ashit Hegde", "Section Head – General Medicine, Critical Care and HealthCheck, Consultant – General Medicine and Critical Care Medicine", "MD", "C:\\Users\\Payal\\OneDrive\\Desktop\\hospital java\\men6.jpg"));
        allDoctors.add(new Doctor("Dr. B. K. Misra", "Head of Department of Surgery and Section Head - Neurosurgery & GammaKnife", "MS (Gen. Surg), MCh (Neurosurgery), Diplomate National Board (Neurosurgery)","C:\\Users\\Payal\\OneDrive\\Desktop\\hospital java\\men9.jpg"));
        allDoctors.add(new Doctor("Dr. John Doe", "Senior Consultant, Cardiology", "MD, FACC", "C:\\Users\\Payal\\OneDrive\\Desktop\\hospital java\\men8.jpg"));
        allDoctors.add(new Doctor("Dr. Jane Smith", "Consultant, Pediatrics", "MD, FAAP", "C:\\Users\\Payal\\OneDrive\\Desktop\\hospital java\\women10.jpg"));
        allDoctors.add(new Doctor("Dr. Emily Johnson", "Consultant, Dermatology", "MD, FAAD", "C:\\Users\\Payal\\OneDrive\\Desktop\\hospital java\\women2jpg.jpg"));
        allDoctors.add(new Doctor("Dr. Michael Brown", "Consultant, Orthopedics", "MD, FAAOS", "C:\\Users\\Payal\\OneDrive\\Desktop\\hospital java\\men2.jpg"));
        allDoctors.add(new Doctor("Dr. Sarah Davis", "Consultant, Neurology", "MD, FAAN", "C:\\Users\\Payal\\OneDrive\\Desktop\\hospital java\\women4.jpg"));
        allDoctors.add(new Doctor("Dr. David Wilson", "Consultant, Gastroenterology", "MD, FACG", "C:\\Users\\Payal\\OneDrive\\Desktop\\hospital java\\men1.jpg"));
        allDoctors.add(new Doctor("Dr. Alice Johnson", "Consultant, Ophthalmology", "MD, FACS", "C:\\Users\\Payal\\OneDrive\\Desktop\\hospital java\\women8.jpg"));
        allDoctors.add(new Doctor("Dr. Robert Martin", "Consultant, Rheumatology", "MD, FACR", "C:\\Users\\Payal\\OneDrive\\Desktop\\hospital java\\men5.jpg"));
        allDoctors.add(new Doctor("Dr. Laura Lee", "Consultant, Endocrinology", "MD, FACE", "C:\\Users\\Payal\\OneDrive\\Desktop\\hospital java\\women6.jpg"));
        allDoctors.add(new Doctor("Dr. James White", "Consultant, Infectious Disease", "MD, FIDSA","C:\\Users\\Payal\\OneDrive\\Desktop\\hospital java\\men4.jpg"));
        allDoctors.add(new Doctor("Dr. Nancy King", "Consultant, Psychiatry", "MD, FAPA", "C:\\Users\\Payal\\OneDrive\\Desktop\\hospital java\\women3.jpg"));
        allDoctors.add(new Doctor("Dr. Chris Adams", "Consultant, Pulmonology", "MD, FCCP","C:\\Users\\Payal\\OneDrive\\Desktop\\hospital java\\men7.jpg"));
        allDoctors.add(new Doctor("Dr. Karen Scott", "Consultant, Allergy and Immunology", "MD, FAAAAI", "C:\\Users\\Payal\\OneDrive\\Desktop\\hospital java\\men9.jpg"));
        allDoctors.add(new Doctor("Dr. Anthony Clark", "Consultant, Nephrology", "MD, FASN", "C:\\Users\\Payal\\OneDrive\\Desktop\\hospital java\\men1.jpg"));
        allDoctors.add(new Doctor("Dr. Rachel Walker", "Consultant, Hematology", "MD, FACP", "C:\\Users\\Payal\\OneDrive\\Desktop\\hospital java\\women4.jpg"));

        if (letter.equals("ALL")) {
            return allDoctors;
        }

        List<Doctor> filteredDoctors = new ArrayList<>();
        for (Doctor doctor : allDoctors) {
            if (doctor.getName().startsWith("Dr. " + letter)) {
                filteredDoctors.add(doctor);
            }
        }
        return filteredDoctors;
    }

    private static JPanel createDoctorPanel(String name, String title, String qualifications, String imagePath) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setPreferredSize(new Dimension(250, 300)); // Fixed size for each panel
        panel.setMaximumSize(new Dimension(250, 300));
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.BLACK, 1),
                BorderFactory.createEmptyBorder(10, 10, 10, 10))); // Rectangle border with padding

          panel.setBackground(Color.decode("#37aacd"));
          
        JLabel profilePictureLabel = new JLabel();
        profilePictureLabel.setPreferredSize(new Dimension(100, 100)); // Square profile picture
        profilePictureLabel.setMaximumSize(new Dimension(100, 100));
        profilePictureLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1)); // Black border for the picture
        profilePictureLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Load and set the image
        ImageIcon profilePicture = new ImageIcon(imagePath);
        Image scaledImage = profilePicture.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
        profilePictureLabel.setIcon(new ImageIcon(scaledImage));

        JLabel nameLabel = new JLabel(name);
        nameLabel.setFont(new Font("Arial", Font.BOLD, 16));
        nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel titleLabel = new JLabel("<html>" + title + "</html>");
        titleLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel qualificationsLabel = new JLabel(qualifications);
        qualificationsLabel.setFont(new Font("Arial", Font.ITALIC, 12));
        qualificationsLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        
        // Add ActionListener to the button
        

        panel.add(profilePictureLabel);
        panel.add(Box.createVerticalStrut(10)); // Spacer
        panel.add(nameLabel);
        panel.add(Box.createVerticalStrut(10)); // Spacer
        panel.add(titleLabel);
        panel.add(Box.createVerticalStrut(10)); // Spacer
        panel.add(qualificationsLabel);
        panel.add(Box.createVerticalStrut(20)); // Spacer
       

        return panel;
    }

    private static class AlphabetButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            JButton source = (JButton) e.getSource();
            String letter = source.getText();
            updateDoctorList(letter);
        }
    }

    private static class Doctor {
        private String name;
        private String title;
        private String qualifications;
        private String imagePath;

        public Doctor(String name, String title, String qualifications, String imagePath) {
            this.name = name;
            this.title = title;
            this.qualifications = qualifications;
            this.imagePath = imagePath;
        }

        public String getName() {
            return name;
        }

        public String getTitle() {
            return title;
        }

        public String getQualifications() {
            return qualifications;
        }

        public String getImagePath() {
            return imagePath;
        }
    }
}
