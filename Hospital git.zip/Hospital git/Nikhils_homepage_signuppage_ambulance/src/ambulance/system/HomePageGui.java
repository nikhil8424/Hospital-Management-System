package ambulance.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URI;
import javax.swing.border.TitledBorder;

public class HomePageGui {
    //googlemapthingd
    private static void openGoogleMapsWindow() {
        try {
            Desktop.getDesktop().browse(new URI("https://www.google.com/maps?q=19.033205,72.838605"));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        // Create the main frame
        JFrame frame = new JFrame("Hospital GUI");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1200, 800);

        // Set background color of the entire frame
        Color backgroundColor = new Color(228, 241, 238);
        frame.getContentPane().setBackground(backgroundColor);

        // Main content panel
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBackground(backgroundColor);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.weightx = 1;
        gbc.weighty = 1;

        // For Patients panel
        JPanel forPatientsPanel = new JPanel(new GridBagLayout());
        TitledBorder border = BorderFactory.createTitledBorder("For Patients");
        border.setTitleFont(new Font("Arial", Font.BOLD, 24));
        forPatientsPanel.setBorder(border);
        forPatientsPanel.setBackground(backgroundColor);
        String[] services = {
            "Consultation", "Admission Process", "Insurance & TPA", "Hospital Tour",
            "24*7 Emergency", "E-Brochure", "Short Stay Service"
        };

        GridBagConstraints patientsGbc = new GridBagConstraints();
        patientsGbc.insets = new Insets(10, 10, 10, 10);
        patientsGbc.weightx = 1;
        patientsGbc.weighty = 1;
        patientsGbc.fill = GridBagConstraints.HORIZONTAL;

        for (int i = 0; i < services.length; i++) {
            patientsGbc.gridx = i % 4;
            patientsGbc.gridy = i / 4;
            JButton button = new JButton(services[i]);
            button.setPreferredSize(new Dimension(200, 50));
            button.setBackground(new Color(0, 51, 153));
            button.setForeground(Color.WHITE);
            button.setFont(new Font("Arial", Font.PLAIN, 20));
            if (services[i].equals("E-Brochure")) {
                button.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        try {
                            Desktop.getDesktop().browse(new URI("https://hinduja-prod-assets.s3.ap-south-1.amazonaws.com/s3fs-public/2024-04/All%203%20booklet.pdf?VersionId=ADIij3yhcrDz4QsK_lfjvqpON55r16yT"));
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                });
            } else if (services[i].equals("Hospital Tour")) {
                button.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        openGoogleMapsWindow();
                    }
                });
            } else if (services[i].equals("Consultation")) {
                button.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        new DoctorSearchAndAppointmentGUI();
                        DoctorSearchAndAppointmentGUI.main(null);
                    }
                });
            } else if (services[i].equals("Admission Process")) {
                button.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        HospitalAdmissionGUI.main(null);
                    }
                });
            } else if (services[i].equals("Insurance & TPA")) {
                button.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        MedicalInsuranceGUI.main(null);
                    }
                });
            } else if (services[i].equals("Short Stay Service")) {
                button.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        ShortStay.main(null);
                    }
                    
                });
                
            }
            forPatientsPanel.add(button, patientsGbc);
        }

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 4;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        mainPanel.add(forPatientsPanel, gbc);

        // Doctor search panel
        JPanel doctorSearchPanel = new JPanel(new GridBagLayout());
        TitledBorder doctorSearchBorder = BorderFactory.createTitledBorder("Our Academics and Community");
        doctorSearchBorder.setTitleFont(new Font("Arial", Font.BOLD, 24));
        doctorSearchPanel.setBorder(doctorSearchBorder);
        doctorSearchPanel.setBackground(backgroundColor);

        GridBagConstraints doctorGbc = new GridBagConstraints();
        doctorGbc.insets = new Insets(5, 5, 5, 5);
        doctorGbc.weightx = 1;
        doctorGbc.weighty = 1;
        doctorGbc.fill = GridBagConstraints.BOTH;

        // Load images and resize them to the same size
        ImageIcon imh1 = new ImageIcon("imh1.png");
        ImageIcon imh2 = new ImageIcon("imh2.png");
        ImageIcon imh3 = new ImageIcon("imh2.png");

        int width = Math.min(imh1.getIconWidth(), Math.min(imh2.getIconWidth(), imh3.getIconWidth()));
        int height = Math.min(imh1.getIconHeight(), Math.min(imh2.getIconHeight(), imh3.getIconHeight()));

        ImageIcon resizedImh1 = new ImageIcon(imh1.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH));
        ImageIcon resizedImh2 = new ImageIcon(imh2.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH));
        ImageIcon resizedImh3 = new ImageIcon(imh3.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH));

        // Create labels for the images
        JLabel imh1Label = new JLabel(resizedImh1);
        JLabel imh2Label = new JLabel(resizedImh2);
        JLabel imh3Label = new JLabel(resizedImh3);

        // Create labels for the text
        JLabel schoolLabel = new JLabel("               Institude of Medical Science");
        JLabel collegeLabel = new JLabel("              Institude of Medical Nursing");
        JLabel communityLabel = new JLabel("                community");

        // Set font for the text labels
        schoolLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        collegeLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        communityLabel.setFont(new Font("Arial", Font.PLAIN, 20));

        // Add the 'school' label
        doctorGbc.gridx = 0;
        doctorGbc.gridy = 0;
        doctorGbc.gridwidth = 1;
        doctorGbc.gridheight = 1;
        doctorGbc.anchor = GridBagConstraints.CENTER;
        doctorSearchPanel.add(schoolLabel, doctorGbc);

        // Add the image for 'school'
        doctorGbc.gridx = 0;
        doctorGbc.gridy = 1;
        doctorSearchPanel.add(imh1Label, doctorGbc);

        // Add the 'college' label
        doctorGbc.gridx = 1;
        doctorGbc.gridy = 0;
        doctorSearchPanel.add(collegeLabel, doctorGbc);

        // Add the image for 'college'
        doctorGbc.gridx = 1;
        doctorGbc.gridy = 1;
        doctorSearchPanel.add(imh2Label, doctorGbc);

        // Add the 'community' label
        doctorGbc.gridx = 2;
        doctorGbc.gridy = 0;
        doctorSearchPanel.add(communityLabel, doctorGbc);

        // Add the image for 'community'
        doctorGbc.gridx = 2;
        doctorGbc.gridy = 1;
        doctorSearchPanel.add(imh3Label, doctorGbc);

        // Add the doctor search panel to the main panel
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        mainPanel.add(doctorSearchPanel, gbc);

        // About panel
        JPanel aboutPanel = new JPanel(new BorderLayout());
        TitledBorder aboutBorder = BorderFactory.createTitledBorder("About Life careHospital");
        aboutBorder.setTitleFont(new Font("Arial", Font.BOLD, 24));
        aboutPanel.setBorder(aboutBorder);
        aboutPanel.setBackground(backgroundColor);

        JLabel aboutLabel = new JLabel("<html><body>"
            + "<h2>About life care hospital</h2>"
            + "<p>“Our healthcare journey commenced in 2009 by the shree atalsharma, "
            + "with a vision to provide quality healthcare for all. Over the last seven decades, "
            + "we have passionately followed this philosophy and today the hospital is regarded "
            + "as one of the top hospitals in Mumbai and one of the best hospitals in India. "
            + "We commit to move forward with greater zeal and determination to set new benchmarks "
            + "in medical excellence and patient care.”<br><br>"
            + "Health and Education are the birth right of every citizen"
            + "</p></body></html>");

        aboutLabel.setHorizontalAlignment(SwingConstants.CENTER);
        aboutLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        aboutPanel.add(aboutLabel, BorderLayout.CENTER);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weighty = 1;  // This makes the about panel take remaining vertical space
        mainPanel.add(aboutPanel, gbc);

        frame.add(mainPanel, BorderLayout.CENTER);

        // Bottom panel for "Know More" button
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.setBackground(backgroundColor);

        JButton knowMoreButton = new JButton("KNOW MORE");
        knowMoreButton.setFont(new Font("Arial", Font.BOLD, 16));
        knowMoreButton.setBackground(new Color(0, 51, 153));
        knowMoreButton.setForeground(Color.WHITE);
        knowMoreButton.setPreferredSize(new Dimension(150, 50));
        bottomPanel.add(knowMoreButton);

        frame.add(bottomPanel, BorderLayout.SOUTH);

        // Set frame visibility
        frame.setVisible(true);
    }
}
