package ambulance.system;


/*

 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Stafff extends javax.swing.JFrame {

   
    public Stafff() {
        initComponents();
        loadData();
    }

   

private void loadData() {
    // Define the column names for the table
    String[] columnNames = {"Staff ID", "First Name", "Last Name", "Gender", "Date of Birth", "Designation"};
    
    // Create a DefaultTableModel with the column names
    DefaultTableModel model = new DefaultTableModel(columnNames, 0);

    try (Connection con = DBConnection.getConnection()) {
        System.out.println("Connected successfully");

        String query = "SELECT * FROM employee"; // Your SQL query
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery(query);

        // Process the ResultSet and add rows to the DefaultTableModel
        while (rs.next()) {
            int staff_id = rs.getInt("Staff_id");
            String first_name = rs.getString("First_name");
            String last_name = rs.getString("Last_name");
            String gender = rs.getString("Gender");
            String date_of_birth = rs.getString("Date_of_Birth");
            String designation = rs.getString("Designation");

            // Add a row to the model
            model.addRow(new Object[]{staff_id, first_name, last_name, gender, date_of_birth, designation});
        }

        // Set the model to your JTable
        jTable1.setModel(model);

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
    }
}

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 204, 204));

        jLabel2.setFont(new java.awt.Font("Segoe UI Black", 1, 36)); // NOI18N
        jLabel2.setText("Staff");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(14, 14, 14))
        );

        jLabel1.setFont(new java.awt.Font("Calibri Light", 1, 18)); // NOI18N
        jLabel1.setText("Staff Listing");

        jTable1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, java.awt.Color.black, null, null));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"", "", "", "", "", ""},
                {"", "", "", "", "", ""},
                {"", "", "", "", "", ""},
                {"", "", "", "", "", ""},
                {"", "", "", "", "", ""},
                {"", "", "", "", "", ""},
                {"", "", "", "", "", "Support Staff"},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Staff ID", "First Name", "Last Name", "Gender", "DOB", "Designation"
            }
        ));
        jTable1.setToolTipText("");
        jTable1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_LAST_COLUMN);
        jScrollPane1.setViewportView(jTable1);

        jButton1.setBackground(new java.awt.Color(0, 204, 204));
        jButton1.setFont(new java.awt.Font("Calibri Light", 1, 14)); // NOI18N
        jButton1.setText("New Staff+");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(0, 204, 204));
        jButton2.setFont(new java.awt.Font("Calibri Light", 1, 14)); // NOI18N
        jButton2.setText("Delete");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(0, 204, 204));
        jButton3.setFont(new java.awt.Font("Calibri Light", 1, 14)); // NOI18N
        jButton3.setText("Edit");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 252, Short.MAX_VALUE)
                        .addComponent(jButton3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 683, Short.MAX_VALUE)
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(37, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        String firstName = JOptionPane.showInputDialog("Enter First Name:");
    String lastName = JOptionPane.showInputDialog("Enter Last Name:");
    String gender = JOptionPane.showInputDialog("Enter Gender (Male/Female):");
    String dateOfBirth = JOptionPane.showInputDialog("Enter Date of Birth (YYYY-MM-DD):");
    String designation = JOptionPane.showInputDialog("Enter Designation:");

    // Check if any input is null or empty
    if (firstName != null && !firstName.trim().isEmpty() &&
        lastName != null && !lastName.trim().isEmpty() &&
        gender != null && !gender.trim().isEmpty() &&
        dateOfBirth != null && !dateOfBirth.trim().isEmpty() &&
        designation != null && !designation.trim().isEmpty()) {
        
        // Insert the new staff record into the database
        addStaff(firstName, lastName, gender, dateOfBirth, designation);
        
    } else {
        JOptionPane.showMessageDialog(null, "All fields must be filled out.");
    }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void addStaff(String firstName, String lastName, String gender, String dateOfBirth, String designation) {
    // SQL query to insert data into the employee table
    String query = "INSERT INTO employee (First_name, Last_name, Gender, Date_of_Birth, Designation) VALUES (?, ?, ?, ?, ?)";

    try (Connection con = DBConnection.getConnection();
         PreparedStatement pstmt = con.prepareStatement(query)) {
        
        // Set the parameters for the prepared statement
        pstmt.setString(1, firstName);
        pstmt.setString(2, lastName);
        pstmt.setString(3, gender);
        pstmt.setString(4, dateOfBirth);
        pstmt.setString(5, designation);

        // Execute the insertion
        int rowsAffected = pstmt.executeUpdate();

        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(this, "Staff added successfully!");
        } else {
            JOptionPane.showMessageDialog(this, "Failed to add staff.");
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
    }
    
    refreshStaffTable();
}
    
    
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        String staffId = JOptionPane.showInputDialog("Enter Staff ID to Delete:");
        
        if (staffId != null && !staffId.trim().isEmpty()) {
            deleteStaff(staffId);
        } else {
            JOptionPane.showMessageDialog(null, "Staff ID cannot be empty.");
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void deleteStaff(String staffId) {
    // SQL query to delete a staff record by ID
    String query = "DELETE FROM employee WHERE Staff_ID = ?";

    try (Connection con = DBConnection.getConnection();
         PreparedStatement pstmt = con.prepareStatement(query)) {
        
        // Set the parameter for the prepared statement
        pstmt.setString(1, staffId);

        // Execute the deletion
        int rowsAffected = pstmt.executeUpdate();

        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(this, "Staff deleted successfully!");
            // Optionally, refresh the table to reflect changes
            refreshStaffTable();
        } else {
            JOptionPane.showMessageDialog(this, "No staff found with the given ID.");
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
    }
}
    
    private void refreshStaffTable() {
    // Assuming you have a JTable named staffTable and a DefaultTableModel named tableModel
    DefaultTableModel tableModel = (DefaultTableModel) jTable1.getModel();
    tableModel.setRowCount(0); // Clear existing rows

    String query = "SELECT * FROM employee";
    try (Connection con = DBConnection.getConnection();
         Statement stmt = con.createStatement();
         ResultSet rs = stmt.executeQuery(query)) {
        
        // Iterate through the result set and add rows to the table model
        while (rs.next()) {
            Object[] row = {
                rs.getString("Staff_ID"),
                rs.getString("First_name"),
                rs.getString("Last_name"),
                rs.getString("Gender"),
                rs.getString("Date_of_Birth"),
                rs.getString("Designation")
            };
            tableModel.addRow(row);
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
    }
}
   
   
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        int selectedRow = jTable1.getSelectedRow();
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select a staff member to edit.");
        return;
    }
    
    // Retrieve current data from the selected row
    String staffId = jTable1.getValueAt(selectedRow, 0).toString();
    String firstName = jTable1.getValueAt(selectedRow, 1).toString();
    String lastName = jTable1.getValueAt(selectedRow, 2).toString();
    String gender = jTable1.getValueAt(selectedRow, 3).toString();
    String dateOfBirth = jTable1.getValueAt(selectedRow, 4).toString();
    String designation = jTable1.getValueAt(selectedRow, 5).toString();

    // Open input dialog to get new details
    String newFirstName = JOptionPane.showInputDialog(this, "Enter new First Name:", firstName);
    String newLastName = JOptionPane.showInputDialog(this, "Enter new Last Name:", lastName);
    String newGender = JOptionPane.showInputDialog(this, "Enter new Gender (Male/Female):", gender);
    String newDateOfBirth = JOptionPane.showInputDialog(this, "Enter new Date Of Birth (YYYY-MM-DD):", dateOfBirth);
    String newDesignation = JOptionPane.showInputDialog(this, "Enter new Designation:", designation);

    if (newFirstName != null && newLastName != null && newGender != null && newDateOfBirth != null && newDesignation != null) {
        // Update the staff record in the database
        updateStaff(staffId, newFirstName, newLastName, newGender, newDateOfBirth, newDesignation);
        
        // Refresh the table
        refreshStaffTable();
    } else {
        JOptionPane.showMessageDialog(this, "All fields must be filled.");
    }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void updateStaff(String staffId, String firstName, String lastName, String gender, String dateOfBirth, String designation) {
    String query = "UPDATE employee SET First_name = ?, Last_name = ?, Gender = ?, Date_of_Birth = ?, Designation = ? WHERE Staff_ID = ?";
    
    try (Connection con = DBConnection.getConnection();
         PreparedStatement pstmt = con.prepareStatement(query)) {
        
        // Set the parameters for the prepared statement
        pstmt.setString(1, firstName);
        pstmt.setString(2, lastName);
        pstmt.setString(3, gender);
        pstmt.setString(4, dateOfBirth);
        pstmt.setString(5, designation);
        pstmt.setString(6, staffId);

        // Execute the update
        int rowsAffected = pstmt.executeUpdate();

        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(this, "Staff updated successfully!");
        } else {
            JOptionPane.showMessageDialog(this, "Failed to update staff.");
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
    }
    refreshStaffTable();
}
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Stafff.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Stafff.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Stafff.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Stafff.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
   

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Stafff().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
