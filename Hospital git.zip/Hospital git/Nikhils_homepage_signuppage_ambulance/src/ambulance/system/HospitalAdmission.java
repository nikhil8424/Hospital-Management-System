package ambulance.system;
public class HospitalAdmission {

    public Object main(Object object) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'main'");
    }

}
