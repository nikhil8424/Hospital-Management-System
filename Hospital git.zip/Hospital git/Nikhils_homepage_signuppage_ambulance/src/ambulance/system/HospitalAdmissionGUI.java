package ambulance.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HospitalAdmissionGUI {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(HospitalAdmissionGUI::createAndShowGUI);
    }

    private static void createAndShowGUI() {
        JFrame frame = new JFrame("Hospital Admission");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.getContentPane().setBackground(Color.WHITE);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBackground(Color.WHITE);

        // Create a panel for the title, description, and image
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(Color.WHITE);
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        JLabel titleLabel = new JLabel("<html>Your Hospital Admission - Inpatient Services<br><br>We assure you the best medical care &<br> a comfortable stay.</html>");
        titleLabel.setFont(new Font("Georgia", Font.ITALIC | Font.BOLD, 24));
        titleLabel.setForeground(new Color(20, 107, 7));
        topPanel.add(titleLabel, BorderLayout.NORTH);

        // Add an image to the top panel (change path to your image)
        ImageIcon imageIcon = new ImageIcon("C:\\Users\\Payal\\OneDrive\\Desktop\\hospital final\\Delving-into-Doctor-Patient-Ratio.jpg");
        JLabel imageLabel = new JLabel(imageIcon);
        topPanel.add(imageLabel, BorderLayout.CENTER);

        mainPanel.add(topPanel);

        String[] sections = {
                "Pre Admission",
                "Room Types and Facilities",
                "At Admission",
                "During Your Stay",
                "Visitors Policy"
        };

        String[] contents = {
                "<html>" +
                 
                        "1. If your doctor at P. D. Hinduja Hospital has advised hospitalization for medical care or surgery, kindly submit the details at the admissions counter located at IPD building ground floor, indicating your desired day for admission and your preferred room type.<br><br>" +
                        "2. In case you have been advised surgery, kindly get the date of surgery confirmed by the consultant since prior allotment of operation theatre will be required.<br><br>" +
                        "3. Due to high demand for surgeries at the hospital and our surgeon’s busy schedule, you would be required to pay a reservation deposit for confirming your surgery. Our admission department will guide you with further details.<br><br>" +
                        "4. You will receive a call from our admissions / billing department on the date of admission confirming your bed availability and the time. In case you don’t receive a call please call on 022 69233030/022 69233031/ 022 4448524 after 01:00 pm to confirm your bed allocation.<br><br>" +
                        "5. While all efforts will be made to give bed/class of your choice, this may not be always possible as it will depend on vacation/discharges and medical status of previous occupant, which cannot be predicted.<br><br>" +
                        "6. Kindly bring the following for your stay<br>" +
                        "- The medicines you are currently consuming and all concerned Medical Reports and X-rays.<br>" +
                        "- A list of any known allergies and sensitivities.<br>" +
                        "- Your personal toiletries, if you wish and your slippers / footwear.<br>" +
                        "- It is advisable to keep some cash for miscellaneous purposes in case of emergency.<br><br>" +
                        "7. Our Short Stay Service (day care) facility caters to patients undergoing procedures that do not require overnight stay at the hospital. For such cases, you may contact 022-69233012." +
                        "</html>",
                "<html>" +
                        "<b>Deluxe:</b><br>" +
                        "An exclusive private room with attached bath,<br>" +
                        "Comfortable sofa for patient's relative,<br>" +
                        "TV, Telephone with STD/ISD facilities,<br>" +
                        "Electronic safe for keeping valuables,<br>" +
                        "Complimentary newspaper & magazine,<br>" +
                        "Welcome kit with slippers,<br>" +
                        "Exclusive medicine box on discharge.<br><br>" +

                        "<b>Special:</b><br>" +
                        "A private room with attached bath,<br>" +
                        "Comfortable sofa for patient's relative,<br>" +
                        "TV, Telephone with STD/ISD facilities,<br>" +
                        "Complimentary newspaper & magazine,<br>" +
                        "Welcome kit with slippers,<br>" +
                        "Exclusive medicine box on discharge.<br><br>" +

                        "<b>Median A:</b><br>" +
                        "A twin sharing room with attached bath,<br>" +
                        "Sofa for patient's relative,<br>" +
                        "Telephone with STD/ISD facilities,<br>" +
                        "Complimentary newspaper, welcome kit.<br><br>" +

                        "<b>Median B:</b><br>" +
                        "A twin sharing cubical with common bath in the wing,<br>" +
                        "Sofa for patient's relative,<br>" +
                        "Mineral water during the entire stay.<br><br>" +

                        "<b>Median:</b><br>" +
                        "4 to 6 patients in a cubical with common bath in the wing,<br>" +
                        "Chair for patient's relative.<br><br>" +

                        "<b>Additional Policies:</b><br>" +
                        "- All rooms provided with complimentary mineral water and Wi-Fi connectivity.<br>" +
                        "- Bed charges are calculated from 11:00 am to 11:00 am irrespective of the time of admission.<br>" +
                        "- If discharge is delayed beyond 11:00 am till 3:00 pm, half day's bed charges will be applied.<br>" +
                        "- There is no service charge on the hospital bill.<br>" +
                        "- Foreign nationals & NRI will be charged a suitable surcharge on the gross bill." +
                        "</html>",
                "<html>" +
                        "<p>Please present a copy of Pan Card / Aadhar Card of patient.</p><br>" +
                        "<p>After telephonic confirmation of bed, you can come to the hospital. You or your caretaker can proceed to the admissions counter, ground floor IPD building to complete the admission process.</p><br>" +
                        "<p>At the admission counter, please present the OT booking form or Doctors Note, HH No., and the reservation deposit receipt if any. You will need to make the payment for the balance deposit amount and sign the necessary admission / declaration forms.</p><br>" +
                        "<p>For corporate clients credit memo / letter with billing class or Identity Card for Emergency Admission needs to be shown for reference.</p><br>" +
                        "<p>We constantly strive to provide you a bed / room as per your needs as quickly as possible. However, sometimes you may face some delay in obtaining an allotment, due to reasons beyond our control, for which we regret any inconvenience caused.</p><br>" +
                        "<p>At the time of admission if you have not been allocated the bed of your billing choice (higher or lower), kindly give your request in writing to the staff on duty.</p><br>" +
                        "<p>Special facilities are provided for Suite, Deluxe, Special class patients & Corporate Clients. On arrival, please contact the Lobby Receptionist.</p><br>" +
                        "<p><strong>Payment Options:</strong></p><br>" +
                        "<ul>" +
                        "<li>Deposits and Payments can be made in cash / via Bank Draft / Traveller's Cheque / credit / debit card or AMEX cards at the hospital. You may also make payments before coming to the hospital online at Link, OR via NEFT transfer, and carry the payment receipt/bank acknowledgement with UTR No.</li><br>" +
                        "<li>Demand Draft / Pay Order is to be made in favour of \"P. D. Hinduja National Hospital & Medical Research Centre\".</li><br>" +
                        "<li>Cash Transaction Limit: Rs. 1,99,999/- for admission w.e.f. 01-April-2017.</li><br>" +
                        "<li>NEFT Bank Details : IndusInd Bank Account No : 100013463987; Account Name: National Health & Education Society; IFSC Code: INDB0000503 .</li><br>" +
                        "</ul>" +
                        "</html>",
                "<html>" +
                        "<p>When you arrive at your room, our staff will orientate you to the ward and the facilities available.</p><br>" +
                        "<p>In order to help us serve you better, please provide accurate and full information about your medical problems, past medical history, medication taken, inform the doctor or nurse of any sudden changes in your condition, and follow the treatment plan recommended by the doctor.</p><br>" +
                        "<p>We ensure complete confidentiality and privacy of your medical condition and treatment. Please go through the patient rights and responsibilities document available with our staff.</p><br>" +
                        "<p>During your stay, your doctor may prescribe some additional tests, procedures, or even surgery, only if necessary depending on your medical condition for your treatment. Since these may not have been planned during your admission, you may need to pay additional deposit.</p><br>" +
                        "<p>It is advisable for one relative to be present in the room or ward during your stay.</p><br>" +
                        "<p>The hospital kitchen is equipped to serve you well-balanced vegetarian meals. Special diets will be served as prescribed. Home food may be permitted on \"medical grounds\". Caretakers' meals can be provided in the hospital at an extra cost.</p><br>" +
                        "<p>For any assistance during your stay regarding housekeeping, toilets, ACs, lights, TV, meals, etc., you may call 3232 from your room phone or contact the duty nurse.</p><br>" +
                        "<p>Every day you will receive an SMS on your mobile number registered at the hospital giving your current accrued bill amount. We would appreciate if you settle any outstanding amount within 24 hours. (Please note that admissions / security deposit is not adjusted against these charges).</p><br>" +
                        "<p>If you wish to change your room type (higher or lower) after admission, please give a written request to our staff. We will try our best to accommodate your request, subject to the availability of beds. However, all charges shall be billed for higher class retrospectively. A request for lowering class in ICU will be after a minimum 3-day stay.</p><br>" +
                        "</html>",
                "<html>" +
                        "<p>The visiting hours are as follows, with a valid visitor pass only:</p><br>" +
                        "<p><strong>Monday to Saturday:</strong> 05:00 pm to 07:00 pm</p><br>" +
                        "<p><strong>Sunday and National Holidays:</strong> 10:00 am to 11:00 am & 05:00 pm to 07:00 pm</p><br>" +
                        "<p>One pass for an attendant is issued for shared rooms / common wards and two passes for Special, Deluxe & Suite classes.</p><br>" +
                        "<p>One additional visitor’s pass (07:00 am - 07:00 pm) per patient is issued by the security department (Valid for three days) on request in the prescribed form available with nursing staff in each ward and with the recommendation by treating consultant only.</p><br>" +
                        "<p>The Visitor's Pass is \"Not Transferable\" & if found with any other person than the person whose name is on the pass; the pass will be confiscated & a fine will be imposed.</p><br>" +
                        "<p>Children below 15 years are not permitted at patient areas, bedside due to safety reasons.</p><br>" +
                        "</html>"
        };

        for (int i = 0; i < sections.length; i++) {
            CollapsiblePanel panel = new CollapsiblePanel(sections[i], contents[i]);
            mainPanel.add(panel);
        }

        // Add mainPanel to a JScrollPane
        JScrollPane scrollPane = new JScrollPane(mainPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        frame.add(scrollPane);
        frame.setVisible(true);
    }

    static class CollapsiblePanel extends JPanel {
        private final JButton toggleButton;
        private final JPanel contentPanel;

        public CollapsiblePanel(String title, String content) {
            setLayout(new BorderLayout());
            setBackground(Color.WHITE);

            toggleButton = new JButton(title + " ▼");
            toggleButton.setFont(new Font("Arial", Font.PLAIN, 18));
            toggleButton.setForeground(new Color(0, 51, 153));
            toggleButton.setHorizontalAlignment(SwingConstants.LEFT);
            toggleButton.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
            toggleButton.setBackground(Color.WHITE);
            toggleButton.addActionListener(new ToggleButtonListener());

            contentPanel = new JPanel(new BorderLayout());
            contentPanel.setBackground(Color.WHITE);
            JLabel contentLabel = new JLabel(content);
            contentLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
            contentPanel.add(contentLabel, BorderLayout.NORTH);
            contentPanel.setVisible(false);

            add(toggleButton, BorderLayout.NORTH);
            add(contentPanel, BorderLayout.CENTER);

            setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        }

        private class ToggleButtonListener implements ActionListener {
            @Override
            public void actionPerformed(ActionEvent e) {
                boolean isVisible = contentPanel.isVisible();
                contentPanel.setVisible(!isVisible);
                toggleButton.setText(isVisible ? toggleButton.getText().replace("▲", "▼") : toggleButton.getText().replace("▼", "▲"));
                contentPanel.revalidate();
                contentPanel.repaint();
            }
        }
    }
}