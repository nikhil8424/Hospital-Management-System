package ambulance.system;
import javax.swing.*;
import java.awt.*;

public class MedicalInsuranceGUI {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(MedicalInsuranceGUI::createAndShowGUI);
    }

    private static void createAndShowGUI() {
        // Create the main frame
        JFrame frame = new JFrame("Hospital Admission");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 800);

        // Create a panel for the main content
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(173, 216, 230)); // Light blue background color

        // Create a panel for the image and the text
        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setBackground(new Color(173, 216, 230)); // Light blue background color
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(0, 20, 20, 20); // Adjusted insets for top, bottom, left, right space

        // Load the original image
        ImageIcon originalIcon = new ImageIcon("C:\\Users\\Payal\\OneDrive\\Desktop\\hospital final\\images.jpg"); // Change the path to your image
        Image originalImage = originalIcon.getImage();
        // Scale the image down
        Image scaledImage = originalImage.getScaledInstance(400, 400, Image.SCALE_SMOOTH); // Change width and height as needed
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        // Create a label for the scaled image
        JLabel imageLabel = new JLabel(scaledIcon);
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.CENTER; // Center align image
        gbc.weightx = 0.5; // Give more weight to image column
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.NONE; // Ensure the image label doesn't stretch
        centerPanel.add(imageLabel, gbc);

        // Create a panel for the text
        JPanel textPanel = new JPanel(new BorderLayout());
        textPanel.setBackground(new Color(173, 216, 230)); // Light blue background color

        // Create a label for the title and description text
        JLabel titleLabel = new JLabel("<html><div style='text-align: left;'>Medical Insurance & TPA Services<br><br>Avail cashless hospitalization through your insurance provider.</div></html>");
        titleLabel.setFont(new Font("Georgia", Font.ITALIC | Font.BOLD, 24)); // Change the font family, style, and size
        titleLabel.setForeground(new Color(20, 107, 7)); // Change the text color
        titleLabel.setHorizontalAlignment(SwingConstants.LEFT); // Align text to the left
        textPanel.add(titleLabel, BorderLayout.NORTH);

        // Add the text panel to the left of centerPanel
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.CENTER; // Center align text
        gbc.weightx = 0.5; // Give more weight to text column
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.NONE; // Ensure the text panel doesn't stretch
        centerPanel.add(textPanel, gbc);

        // Add the center panel to the main panel
        mainPanel.add(centerPanel, BorderLayout.NORTH);

        // Create the tabbed pane
        JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);

        // Set background color of tabbedPane
        tabbedPane.setBackground(new Color(173, 216, 230));  // Light blue color

        tabbedPane.addTab("Pre admission & Admission Requirements", createPreAdmissionTab());
        tabbedPane.addTab("Getting Discharged", createGettingDischargedTab());
        tabbedPane.addTab("Reimbursement", createReimbursementTab());
        tabbedPane.addTab("Emergency", createEmergencyTab());

        // Increase the size of the tabs
        for (int i = 0; i < tabbedPane.getTabCount(); i++) {
            JLabel label = new JLabel(tabbedPane.getTitleAt(i));
            label.setPreferredSize(new Dimension(250, 50)); // Set desired size here
            label.setHorizontalAlignment(SwingConstants.CENTER);
            label.setBackground(new Color(173, 216, 230));  // Light blue color
            label.setOpaque(true);  // Make sure the background color is visible
            tabbedPane.setTabComponentAt(i, label);
        }

        // Add the tabbed pane to the main panel
        mainPanel.add(tabbedPane, BorderLayout.CENTER);

        // Add the main panel to the frame
        frame.add(mainPanel);

        // Set the frame to be visible
        frame.setVisible(true);
    }

    private static JPanel createGettingDischargedTab() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(173, 216, 230));  // Light blue color

        JTextPane textPane = new JTextPane();
        textPane.setContentType("text/html");
        textPane.setText("<html>"
        + "<style>"
        + "h2 { color: black; font-size: 16px; }"
        + "p { font-family: Segoe UI, Tahoma, Geneva, Verdana, sans-serif; font-size: 14px; font-weight: bold; }"
        + ".bullet { margin-left: 20px; }"  // Updated styling for bullet points
        + "li { font-family: Arial, Helvetica, sans-serif; font-size: 14px; }"  // Change font style for <li> tags
        + "</style>"
        + "<p>You shall be required to:</p>"
        + "<ul>"
        + "<li><b>Settle the difference:</b> If your bill exceeds the designated insurance amount, you will need to pay the difference.</li>"
        + "<li><b>Pay for non-medical expenses:</b> Your policy will not cover non-medical expenses.</li>"
        + "<li><b>Verify bills and prescriptions:</b> Check all bills and prescriptions to ensure that only administered medicines are billed to you.</li>"
        + "<li><b>Note total bill amount:</b> Keep a record of the total bill amount for future reference.</li>"
        + "<li><b>Submit medical documents:</b> Before discharge, submit all medical documents including lab reports, claim forms, discharge summary, and final bill to the hospital.</li>"
        + "</ul>"
        + "<p>The hospital will then submit all necessary documents to the TPA. The TPA processes the bill based on eligibility and actual costs:</p>"
        + "<ul>"
        + "<li>If the treatment cost exceeds the approved sum, the TPA generally approves only a part of the expenses initially.</li>"
        + "<li>After receiving the final bill, discharge summary, and other reports from the hospital, the TPA may approve the entire amount.</li>"
        + "<li>Sometimes, hospitals may request the TPA to increase the approved amount during treatment if needed.</li>"
        + "</ul>"
        + "<p>After TPA approval, the deposit amount of Rs. 7,500 will be refunded to you, with deductions if applicable.</p>"
        + "</html>");
        textPane.setEditable(false);

        panel.add(new JScrollPane(textPane), BorderLayout.CENTER);

        return panel;
    }

    private static JPanel createPreAdmissionTab() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(173, 216, 230));  // Light blue color

        JTextPane textPane = new JTextPane();
        textPane.setContentType("text/html");
        textPane.setText("<html>"
            + "<style>"
            + "h2 { color: black; font-size: 16px; }"
            + "p { font-family: Segoe UI, Tahoma, Geneva, Verdana, sans-serif; font-size: 14px; }"
            + ".step { font-weight: bold; color: orange; font-size: 14px; }"
            + "li { font-family: Segoe UI, Tahoma, Geneva, Verdana, sans-serif; font-size: 14px; }"  // Updated font for <li> items
            + "</style>"
            + "<p>In case of a planned admission, you would have first consulted a doctor who in turn would have advised you on the probable date of hospitalization. In such a case, you must apply for approval of the estimated hospital expenses directly by your TPA at least 4-5 days prior to the date of hospitalization.</p>"
            + "<p>In case you have not applied for pre-authorization sufficiently in advance or if the doctor treating you advises you to get hospitalized immediately after the consultation, our Corporate Help Desk (Phone: 022-24460649 / 24447543) will assist you through the preauthorization procedure. Normal working hours are from 8.00 am to 8.00 pm, Monday to Saturday and on Sunday / Hospital Holidays from 9.00 am to 5.00 pm.</p>"
            + "<p>However, the Corporate/TPA Help Desk is only a facilitator and cannot influence the decision on approval. Your TPA may not grant approval due to reasons such as:</p>"
            + "<ul>"
            + "<li>The ailment for which you are hospitalized is not covered in your policy.</li>"
            + "<li>The information contained in the pre-authorization form is insufficient to approve the request. However, most of the time, the TPA will request additional information from the hospital if needed.</li>"
            + "<li>You have exhausted the sum assured for that year.</li>"
            + "</ul>"
            + "<h2>Pre-authorization Procedure</h2>"
            + "<p class='step'>Step 1: Contact Corporate Help Desk</p>"
            + "<ul>"
            + "<li>Establish contact with the Corporate Help Desk at the hospital or refer to the hospital's information for cashless processing or reimbursement.</li>"
            + "</ul>"
            + "<p class='step'>Step 2: Collect Forms</p>"
            + "<ul>"
            + "<li>Collect the pre-authorization forms pertaining to your TPA, TPA Checklist, and TPA undertaking form from OPD Customer care help desk, Doctor's secretaries, West block help desk, or download these forms.</li>"
            + "<li>Present your Health Insurance card for the staff to assist you appropriately.</li>"
            + "</ul>"
            + "<p class='step'>Step 3: Fill Out Forms</p>"
            + "<ul>"
            + "<li>Your pre-authorization form will have two sections:</li>"
            + "<li>General details on the health insurance policy - to be filled by you. The TPA Help Desk will assist you if needed.</li>"
            + "<li>The treatment recommended for you - to be filled in and duly signed by the treating doctor. Contact the TPA Help Desk for assistance if needed.</li>"
            + "<li>TPA Checklist and TPA undertaking forms are self-explanatory.</li>"
            + "</ul>"
            + "<p class='step'>Step 4: Submission</p>"
            + "<ul>"
            + "<li>Return the completed form (filled and signed) along with copies of the documents mentioned in the TPA checklist to the TPA Help Desk.</li>"
            + "<li>Alternatively, create a single PDF file of all your documents as per the TPA checklist and email it to tpacell@hindujahospital.com, with the subject as 'Patient's name, HH Number, and mobile number'.</li>"
            + "<li>The desk personnel will verify the form for completeness and inform you of any discrepancies.</li>"
            + "</ul>"
            + "<p class='step'>Step 5: Document Upload</p>"
            + "<ul>"
            + "<li>The TPA Help Desk will upload the documents on the portal and transmit them to the TPA office.</li>"
            + "</ul>"
            + "<p class='step'>Step 6: Approval Status</p>"
            + "<ul>"
            + "<li>The TPA Help Desk will notify you of the approval or denial status. The status will also be updated on your registered mobile number and displayed near the TPA Help desk.</li>"
            + "</ul>"
            + "<p class='step'>Step 7: Admission</p>"
            + "<ul>"
            + "<li>At the time of admission, you will be required to pay the differential amount between the admission deposit and TPA approval.</li>"
            + "<li>A TPA deposit payment of Rs. 7,500/- is required on admission, which will be refunded post discharge, subject to completion of all formalities and payment received by the hospital. This process may take 45-90 days.</li>"
            + "</ul>"
            + "</html>");
        textPane.setEditable(false);

        panel.add(new JScrollPane(textPane), BorderLayout.CENTER);

        return panel;
    }

    private static JPanel createReimbursementTab() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(173, 216, 230));  // Light blue color

        JTextPane textPane = new JTextPane();
        textPane.setContentType("text/html");
        textPane.setText("<html>"
            + "<style>"
            + "h2 { color: black; font-size: 20px; }"
            + "p { font-family: Segoe UI, Tahoma, Geneva, Verdana, sans-serif; font-size: 18px; }"
            + ".step { font-weight: bold; color: orange; font-size: 16px; }"
            + "li { font-family: Segoe UI, Tahoma, Geneva, Verdana, sans-serif; font-size: 18px; }"  // Updated font for <li> items
            + "</style>"
            + "<h2>Reimbursement</h2>"
            + "<p class='step'>Q 1) Which documents are required to process reimbursement?</p>"
            + "<ul>"
            + "<li>A) Part A & Part B forms of respective Insurance Company</li>"
            + "<li>B) All original Investigation reports</li>"
            + "<li>C) Original Bills</li>"
            + "<li>D) Indoor Case Paper (if required)</li>"
            + "</ul>"
            + "<p>For queries, you may call 022-69248152/53 from 9am to 4pm.</p>"
            + "<p class='step'>Q 2) Where is Part 'B' form available?</p>"
            + "<p>Please check your insurance company website or contact your Insurance agent.</p>"
            + "<p class='step'>Q 3) Part B form is filled by whom</p>"
            + "<p>Part 'B' is filled by the Medical Record Department after patient's discharge.</p>"
            + "<p class='step'>Q 4) Where is indoor case paper request form available?</p>"
            + "<p>It is available in the medical records department or on the hospital website.</p>"
            + "<p class='step'>Q 5) Which are documents required for Indoor case paper request?</p>"
            + "<p>Patient's signed consent letter/Indoor Case Paper request form with copy of Pan Card / Aadhaar Card / Driving License.</p>"
            + "<p class='step'>Q 6) Is there any charge for Indoor case paper set?</p>"
            + "<p>Yes, charges are applicable. Voucher can be made from any OPD cash counter.</p>"
            + "<p class='step'>Q 7) When shall I receive all Indoor Case Papers?</p>"
            + "<p>You can receive your Indoor Case Papers from the medical record department within 3 working days from the date of application.</p>"
            + "<p>We hope that this information helped you.</p>"
            + "<p>We wish you a speedy recovery.</p>"
            + "<p>P. D. Hinduja Hospital, Mahim</p>"
            + "</html>");
        textPane.setEditable(false);

        panel.add(new JScrollPane(textPane), BorderLayout.CENTER);

        return panel;
    }

    private static JPanel createEmergencyTab() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(173, 216, 230));  // Light blue color

        JTextPane textPane = new JTextPane();
        textPane.setContentType("text/html");
        textPane.setText("<html>"
            + "<style>"
            + "h2 { color: black; font-size: 20px; }"
            + "p { font-family: Segoe UI, Tahoma, Geneva, Verdana, sans-serif; font-size: 18px; }"
            + ".step { font-weight: bold; color: orange; font-size: 16px; }"
            + "</style>"
            + "<h2>Emergency Hospitalization</h2>"
            + "<p>In an emergency hospitalization, the important thing is to get the patient treatment at the earliest. The Corporate Help Desk will take up your case on a fast track basis with your TPA and is likely to receive approvals within 6 hours during any working day.</p>"
            + "<p class='step'>Step 1: Show your health insurance card and fill in the pre-authorization form.</p>"
            + "<p class='step'>Step 2: The Corporate / TPA desk in the hospital will fast track the process for your cashless process. If you cannot wait for the approval, you can pay the deposit demanded by the hospital and start the treatment, with the option to reimburse the expense later on.</p>"
            + "<p class='step'>Step 3: Generally, the time taken to process an emergency case is 6 hours, but this may vary depending upon the insurance company / TPA. You need to follow up with the TPA to know the status of the request.</p>"
            + "</html>");
        textPane.setEditable(false);

        panel.add(new JScrollPane(textPane), BorderLayout.CENTER);

        return panel;
    }
}
